# frozen_string_literal: true

class OpenStruct
  VERSION = "0.2.0"
end
